/****************************************************************************************************
 * File Name: functions.cpp                                                                         *
 * Author: Grace Harris                                                                             *
 * Date: 04/26/2021                                                                                 *
 * Purpose: This program takes in a list of vehicles and allows the user to add or delete vehicles  *
 * and also allows them to save to a new file text for further use.                                 * 
 * **************************************************************************************************/


//Libraries for the main function to use when executing program.

#ifndef PROG5_H 
#define PROG5_H

#include <iostream>
#include <cmath>
#include <string>
#include <iomanip>
#include <fstream>
#include <sstream>
using namespace std;

//structures used in the program of individual variables used to add or delete vehicles.
struct Cost
{
    float numHours;
    float costPerHour;
    float partCost;
    float materialCost;

};

struct Vehicles
{
    string vehicleName;
    string descriptVehicle;
    bool weapons;
    Cost members;

};


// function prototypes that will be used in the program.
void enterVehicles(int &counter, Vehicles automobile[]);
float convertToFloat(string s);
void saveVehiclesToFile(int &counter, Vehicles automobile[]);
void printStatistics(int &counter, Vehicles automobile[]);
void deleteVehicles(int &counter, Vehicles automobile[]);
void printVehicles(int &counter, Vehicles automobile[]);
bool moveArrayElements(string tempInfo, int &counter, Vehicles automobile[]);


#endif