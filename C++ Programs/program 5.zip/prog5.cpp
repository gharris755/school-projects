/****************************************************************************************************
 * File Name: functions.cpp                                                                         *
 * Author: Grace Harris                                                                             *
 * Date: 04/26/2021                                                                                 *
 * Purpose: This program takes in a list of vehicles and allows the user to add or delete vehicles  *
 * and also allows them to save to a new file text for further use.                                 * 
 * **************************************************************************************************/


// Include for the header file that has the function prototypes and libraries needed.

#include "prog5.h"


//Main function that will give the user a menu to make a choice on what to do with the vehicles.
int main()
{

    //Local variables initialized.
    Vehicles automobile[100];
    int counter = 0;
    int choice;
    bool runAgain = true;
    char save;


    do { // loop for the menu to keep taking in input until user is finished adding or deleting vehicles.
        
        cout << "What would you like to do? \n";
        cout << "1. Enter some Vehicles.\n";
        cout << "2. Delete a Vehicle.\n";
        cout << "3. List/Print Vehicles. \n";
        cout << "4. Print Statistics on Vehicle Cost.\n";
        cout << "5. End Program.\n";
        cout << "Enter 1, 2, 3, 4, or 5.  ";
        cin >> choice;

        
        //once a choice is made the program then initiates which function correlates with the choice that is made.
        //Each function takes in the amount of vehicles currently saved and the array of the vehicles to move through.

        if (choice == 1)
        {
            enterVehicles(counter, automobile);
        }

        else if (choice == 2)
        {
            deleteVehicles(counter,automobile);
        }

        else if (choice == 3)
        {
            printVehicles(counter, automobile);
        }

        else if (choice == 4)
        {
            printStatistics(counter, automobile);
        }

        // Action for when user is ready to stop program and gives choice to save to a file one last time or completely exit.
        else if (choice == 5)
        {
            runAgain = false;
            cout << "Would you like to save your vehicle list to a file? (y or n): \n";
            cin >> save;
            if (save == 'y' || save =='Y')
            {
                saveVehiclesToFile(counter, automobile);
            }
        }
        
        else
        {
            cout << "\n\n Invalid input. Please choose an option from the menu. \n\n";
        }

    }while(runAgain);
    return 0;
}