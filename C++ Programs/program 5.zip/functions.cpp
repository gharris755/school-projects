/****************************************************************************************************
 * File Name: functions.cpp                                                                         *
 * Author: Grace Harris                                                                             *
 * Date: 04/26/2021                                                                                 *
 * Purpose: This program takes in a list of vehicles and allows the user to add or delete vehicles  *
 * and also allows them to save to a new file text for further use.                                 * 
 * **************************************************************************************************/


// including header file for the prototypes and libraries will be used.
#include "prog5.h"

// Function to begin entering files of vehicles or if the user wishes to manually input new vehicles.
void enterVehicles(int &counter, Vehicles automobile[]) 
{
    
    //Local variables to be initialized in function.
    int option;
    string fileName;
    ifstream inputFile;
    string tempInput;
    bool runAgain = true;

    //Menu within to allow user to choose how they wish to enter the vehicles into program.
    cout << "What do you want to do? \n";
    cout << "1. Load my vehicles from a file.\n";
    cout << "2. Enter one vehicle manually.\n";
    cin >> option;

    //option one initializing for user to input the files from a different file.
    if (option == 1)
    {
        cout << "What is the name of the file with your list of vehicles? (ex. filename.txt) \n";
        cout << "FileName: \n";
        cin >> fileName;
        inputFile.open(fileName);
           
        //validating that the file for input has opened. If it hasn't it will ask for new file to validate.
        while(!inputFile.is_open())
        {
            cout << "Error could not open file! Please enter a file to open (including .txt) \n";
            cin >> fileName;
            inputFile.open(fileName);
        }

        //File is able to open and while loop will move through list inputting each part of the vehicle's information into the automobile array.
        while(inputFile.eof() ==  false)
        {
            //using temp variables to help move vehicle info into the arrays.
            Vehicles tempAuto;
            Cost tempCost;
            tempAuto.members = tempCost;
            getline(inputFile, tempInput, '#');
            tempAuto.vehicleName = tempInput;
            getline(inputFile, tempInput, '#');   
            tempAuto.descriptVehicle = tempInput;
            getline(inputFile, tempInput, '#');
            tempAuto.weapons = stoi(tempInput);
            getline(inputFile, tempInput, '#');
            tempAuto.members.numHours = convertToFloat(tempInput);
            getline(inputFile, tempInput, '#');
            tempAuto.members.costPerHour = convertToFloat(tempInput);
            getline(inputFile, tempInput, '#');
            tempAuto.members.partCost = convertToFloat(tempInput);
            getline(inputFile, tempInput, '#');
            tempAuto.members.materialCost = convertToFloat(tempInput);
            counter++;

        }
   
        //Once process is complete message prompt will state the file has been added into the program.
        cout << "All vehicles from " << fileName << " have been added to the program.\n"; 

    }
    //If menu choice is 2 this loop prompts user for input of each part of the vehicle's information to save into the array.
    else if (option == 2)
    {
        while(runAgain)
        {
            Vehicles tempAuto;
            Cost tempCost;
            tempAuto.members = tempCost;

            cout << "NAME: " << endl; 
            getline(cin, tempInput);
            tempAuto.vehicleName = tempInput;

            cout << "DESCRIPTION: " << endl;
            getline(cin, tempInput);
            tempAuto.descriptVehicle = tempInput;

            cout << "DOES THIS VEHICLE HAVE WEAPONS? (y or n): " << endl; 
            getline(cin, tempInput);

            if (tempInput == "Y" || tempInput == "y")
            {
                tempAuto.weapons = true;
            }

            else
            {
                tempAuto.weapons = false;
            }

            cout << "How many hours do you spend repairing the " << tempAuto.vehicleName << "?" << endl;
            getline(cin, tempInput);
            tempAuto.members.numHours = convertToFloat(tempInput);

            cout << "What is the cost per hour for repairing for the " << tempAuto.vehicleName << "?" << endl;
            getline(cin, tempInput);
            tempAuto.members.costPerHour = convertToFloat(tempInput);

            cout << "How much money do you spend on parts for the " << tempAuto.vehicleName << "?" << endl;
            getline(cin, tempInput);
            tempAuto.members.partCost = convertToFloat(tempInput);

            cout << "How much money do you spend on supplies for the " << tempAuto.vehicleName << "?" << endl;
            getline(cin, tempInput);
            tempAuto.members.materialCost = convertToFloat(tempInput);
            counter++;

            cout << "The " << tempAuto.vehicleName << " has been added." << endl; 
            

            cout << "Do you wish to enter new vehicle? (y or n) \n";
            cin >> tempInput;

            if (tempInput == "Y" || tempInput == "y")
            {
                runAgain = true;
            }

            else
            {
                runAgain = false;
            }

        } 
    }  
}

//This function helps convert numbers that are stated as strings to be converted into float variables to help with calculating costs of vehicles.
float convertToFloat(string s)
{
    istringstream i(s);
    float x;
    if(!(i >> x))
    {
        x = 0;
    }
    return 0;
}

//This function is used when the user wishes to remove a vehicle from the array list.
void deleteVehicles(int &counter, Vehicles automobile[])
{
    //local temp variable to help move the vehicle that is chosen to delete.
    string tempInput;
    int index;

    
    cout << "The following is a list of all the Vehicles you take care of: \n";
    
    for(index = 0; index < counter; index++ )
    {
        cout << automobile[index].vehicleName << endl;

    }

    cout << "What Vehicle do you wish to remove?\n";
    cout << "VEHICLE NAME: \n";
    getline(cin, tempInput);

    //Once name of vehicle chosen for deletion it is then put through the moveArrayElement function to move the vehicles into a new number order.
    if(moveArrayElements(tempInput, counter, automobile))
    {
        
        cout << "You have removed " << tempInput << ".\n";
        counter--;
    }

    //If name was not deleted a message will prompt stating could not be found to be deleted.
    else
    {
        cout << "Sorry, a vehicle by the name " << tempInput << " could not be found.\n";
    }
    
   
    
}

//This function allows user to save new list of vehicles created to a new file if they wish or to the original text file they inputted from.
void saveVehiclesToFile(int &counter, Vehicles automobile[])
{
    //local variables to open files to output to files the vehicle's information.
    ofstream outputFile;
    string writeFile;
    ifstream inputFile;
    string tempInput;

    cout << "What is the name of your file you wish to write to? \n";
    cout << "FILENAME: \n";
    cin >> writeFile;
    outputFile.open(writeFile, ios::app);

    cout << "Your vehicles have been entered into " << writeFile << endl;
}


//function that goes through array of vehicles and calculate the costs of repair for each vehicle and print the total cost of all vehicle repairs.
void printStatistics(int &counter, Vehicles automobile[])
{
    float cost = 0.0;
    float totalCost = 0.0;


    for(int index =0; index < counter; index++)
    {
        cost = automobile[index+1].members.numHours * automobile[index+1].members.costPerHour + automobile[index+1].members.partCost + automobile[index+1].members.materialCost;
        cout << "Vehicles" << endl;
        cout << endl;
        cout << "Vehicles " << "\t $ \t" << " Cost" << endl;

        cout << automobile[index].vehicleName << "\t   $   " << cost; 

        totalCost = totalCost + cost;

        cout << totalCost;

        cout << endl;



      
    }


    
}

//The function that rearranges new order for the vehicles list once one vehicle is chosen to be deleted and removed from the list.
bool moveArrayElements(string tempInput, int &counter, Vehicles automobile[])
{
   
    int index;
   

    for(index=0; index < counter; index++)
    {
        if(tempInput == automobile[index].vehicleName)
        {
        
            for(index = 0; index < counter; index++)
            {
                automobile[index] = automobile[index+1];
                  
            }
           return true;
        }
         
    }
    
   return false;
}

//Function that allows the user to print the list of vehicles they have created to the screen or to a text file to be saved.
void printVehicles(int &counter, Vehicles automobile[])
{
    int option;
    int index = 0;
    string line(100, '-');
    ofstream outputFile;
    string writeFile;
    
    cout << "What would you like to do? \n";
    cout << "1. Print Vehicle to the Screen.\n";
    cout << "2. Print Vehicle to a file.\n";
    cout << "Choose 1 or 2." << endl;
    cout << "Choice: " << endl;
    cin >> option;

    while(option < 1 || option > 2) 
    {
        cout << "Invalid selection please choose 1 or 2: " << endl;
        cin >> option;
    }

    if(option == 1) 
    {
        for(index=0; index < counter; index++)
        //This part of the function creates the layout of each vehicle's info that is printed either to screen.
        {
            cout << line;
            cout << endl;
            cout << "Vehicle " << (index+1) << ":" << endl;
            cout << "Name:    " << automobile[index].vehicleName << endl;
            cout << "Description:" << endl;
            cout << automobile[index].descriptVehicle << endl;
            cout << "Has Weapons?     " << automobile[index].weapons << endl;
            cout << "Number of Hours to repair the Vehicle:  $" << setprecision(2) << automobile[index].members.numHours << endl;
            cout << "Cost Per Hour:   $" << setprecision(2) << automobile[index].members.costPerHour << endl;
            cout << "Cost for Parts:  $" << setprecision(2) << automobile[index].members.partCost << endl;
            cout << "Supplies Cost:    $" << setprecision(2) << automobile[index].members.materialCost << endl;
            cout << endl;
            cout << endl;
            cout << endl;
        }
    }

    else
    {
        //This part of the function creates the layout of each vehicle's info that is printed either to a file.

        cout << "What is the name of your file you wish to write to?" << endl;
        cout << "FILENAME:  " << endl;
        cin >> writeFile;
        outputFile.open(writeFile, ios::app);

        outputFile << line;
        outputFile << "Vehicle " << (index+1) << ":" << endl;
        outputFile << "Name:    " << automobile[index].vehicleName << endl;
        outputFile << "Description:" << endl;
        outputFile << automobile[index].descriptVehicle << endl;            
        outputFile << "Has Weapons?     " << automobile[index].weapons << endl;
        outputFile << "Number of Hours to repair the Vehicle:  $" << setprecision(2) << automobile[index].members.numHours << endl;
        outputFile << "Cost Per Hour:   $" << setprecision(2) << automobile[index].members.costPerHour << endl;
        outputFile << "Cost for Parts:  $" << setprecision(2) << automobile[index].members.partCost << endl;
        outputFile << "Supplies Cost:    $" << setprecision(2) << automobile[index].members.materialCost << endl;
        outputFile << endl;
        outputFile << endl;
        outputFile << endl; 
           

        cout << "Your vehicles have been entered into " << writeFile << endl;

    }

}
